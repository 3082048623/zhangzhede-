package menu;

import database.ConnectData;

public class Main {
	public static void main(String[] args) throws Exception {
		SignMenu m = new SignMenu();
		m.init();
		
	}
}
